
# simulatr 0.1.0.9002

* Usage of ggplot2 according to the recommendations in the vignette [Using ggplot2 in packages](https://ggplot2.tidyverse.org/articles/ggplot2-in-packages.html)
* Minor improvements, e.g., code style optimized

# simulatr 0.1.0.9001

* First release of simulatr
