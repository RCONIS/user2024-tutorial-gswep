 <!-- badges: start -->
 [![R-CMD-check](https://github.com/fpahlke/simulatr/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/fpahlke/simulatr/actions/workflows/R-CMD-check.yaml)
[![Codecov test coverage](https://codecov.io/gh/fpahlke/simulatr/branch/main/graph/badge.svg)](https://app.codecov.io/gh/fpahlke/simulatr?branch=main)
 <!-- badges: end -->


# simulatr: Generator for Reproducible Fake Data

This repository contains the model solution of *simulatr*, an example package for learning about software development best-practices for R packages.

