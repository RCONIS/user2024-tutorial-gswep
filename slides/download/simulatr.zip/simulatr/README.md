
# simulatr: Generator for Reproducible Fake Data

This repository contains the model solution of *simulatr*, an example package for learning about software development best-practices for R packages.

