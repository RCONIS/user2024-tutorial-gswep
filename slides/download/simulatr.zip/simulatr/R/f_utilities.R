##
## Insert all helper/utility functions here
##